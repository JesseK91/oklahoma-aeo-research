#!/usr/bin/env python3
"""
580 Digital Infrastructure - Local AI Shortlist Inspector & Benchmarker
Performs two real checks:
1. Live website inspection (HTTP status, response time, robots.txt, headings, internal service links, JSON-LD schema).
2. Live search-grounded AI query testing (via Gemini API with Google Search grounding), recording the exact search fan-out queries, cited sources, and shortlisted businesses.

Never fabricates engine results or website findings.
"""

import argparse
import json
import os
import re
import sys
import time
from datetime import datetime
from html.parser import HTMLParser
from typing import Any, Dict, List
from urllib.parse import urljoin, urlparse

import requests


def load_environment():
    """Read explicit process variables only; never scan unrelated project secrets."""
    return dict(os.environ)



ENV = load_environment()


class SiteInspectorParser(HTMLParser):
    def __init__(self, base_url: str):
        super().__init__()
        self.base_url = base_url
        self.base_netloc = urlparse(base_url).netloc.replace("www.", "")
        self.in_title = False
        self.in_h1 = False
        self.in_h2 = False
        self.in_ld_json = False
        self.in_script_or_style = False
        self.hidden_depth = 0
        self.tag_stack: List[tuple] = []
        self.title = ""
        self.meta_description = ""
        self.h1s: List[str] = []
        self.h2s: List[str] = []
        self.ld_json_blocks: List[str] = []
        self.internal_links: List[str] = []
        self.text_chunks: List[str] = []
        self._current_buf: List[str] = []

    def _is_hidden_attrs(self, attr_dict: Dict[str, str]) -> bool:
        if "hidden" in attr_dict or "data-hidden-on-desktop" in attr_dict:
            return True
        if attr_dict.get("aria-hidden", "").lower() == "true":
            return True
        style = attr_dict.get("style", "").lower().replace(" ", "")
        if "display:none" in style or "visibility:hidden" in style:
            return True
        return False

    def handle_starttag(self, tag: str, attrs: List[tuple]):
        attr_dict = {k.lower(): (v or "") for k, v in attrs}
        tag = tag.lower()
        is_hidden = self._is_hidden_attrs(attr_dict)
        self.tag_stack.append((tag, is_hidden))
        if is_hidden:
            self.hidden_depth += 1

        if self.hidden_depth > 0:
            return

        if tag == "title":
            self.in_title = True
            self._current_buf = []
        elif tag == "h1":
            self.in_h1 = True
            self._current_buf = []
        elif tag == "h2":
            self.in_h2 = True
            self._current_buf = []
        elif tag == "meta":
            name = attr_dict.get("name", "").lower()
            if name == "description":
                self.meta_description = attr_dict.get("content", "").strip()
        elif tag == "script":
            if "application/ld+json" in attr_dict.get("type", "").lower():
                self.in_ld_json = True
                self._current_buf = []
            else:
                self.in_script_or_style = True
        elif tag in ("style", "noscript"):
            self.in_script_or_style = True
        elif tag == "a":
            href = attr_dict.get("href", "").strip()
            link_type = attr_dict.get("link_type", "").lower()
            if link_type == "popup" or "popup_target" in attr_dict:
                return
            if href and not href.startswith(("#", "tel:", "mailto:", "javascript:")):
                full = urljoin(self.base_url, href)
                parsed = urlparse(full)
                if parsed.netloc.replace("www.", "") == self.base_netloc:
                    path = parsed.path.rstrip("/") or "/"
                    if path not in self.internal_links:
                        self.internal_links.append(path)

    def handle_endtag(self, tag: str):
        tag = tag.lower()
        if self.tag_stack:
            _, was_hidden = self.tag_stack.pop()
            if was_hidden and self.hidden_depth > 0:
                self.hidden_depth -= 1

        text = " ".join("".join(self._current_buf).split()).strip()
        if tag == "title" and self.in_title:
            self.in_title = False
            if text and not self.title:
                self.title = text
        elif tag == "h1" and self.in_h1:
            self.in_h1 = False
            if text and text not in self.h1s:
                self.h1s.append(text)
        elif tag == "h2" and self.in_h2:
            self.in_h2 = False
            if text and text not in self.h2s:
                self.h2s.append(text)
        elif tag == "script":
            if self.in_ld_json:
                self.in_ld_json = False
                raw_json = "".join(self._current_buf).strip()
                if raw_json:
                    self.ld_json_blocks.append(raw_json)
            self.in_script_or_style = False
        elif tag in ("style", "noscript"):
            self.in_script_or_style = False

    def handle_data(self, data: str):
        if self.hidden_depth > 0:
            return
        if self.in_title or self.in_h1 or self.in_h2 or self.in_ld_json:
            self._current_buf.append(data)
        if not self.in_script_or_style and not self.in_ld_json:
            cleaned = " ".join(data.split())
            if cleaned:
                self.text_chunks.append(cleaned)


def inspect_website(url: str) -> Dict[str, Any]:
    """Fetch and inspect the target website and its robots.txt."""
    if not url:
        return {"inspected": False, "reason": "No website URL provided."}
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    headers = {
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Safari/537.36"
    }
    result: Dict[str, Any] = {"inspected": True, "url": url}

    try:
        t0 = time.time()
        resp = requests.get(url, headers=headers, timeout=15, allow_redirects=True)
        elapsed_ms = int((time.time() - t0) * 1000)
        result["final_url"] = resp.url
        result["status_code"] = resp.status_code
        result["response_time_ms"] = elapsed_ms

        parser = SiteInspectorParser(resp.url)
        parser.feed(resp.text)

        full_text = " ".join(parser.text_chunks)
        result["title"] = parser.title
        result["meta_description"] = parser.meta_description
        result["h1s"] = parser.h1s[:10]
        result["h2s"] = parser.h2s[:15]
        result["internal_paths"] = parser.internal_links[:30]
        result["word_count_estimate"] = len(full_text.split())

        schema_types: List[str] = []
        for raw_block in parser.ld_json_blocks:
            try:
                parsed_json = json.loads(raw_block)
                items = parsed_json if isinstance(parsed_json, list) else [parsed_json]
                for item in items:
                    if isinstance(item, dict):
                        if "@type" in item:
                            t_val = item["@type"]
                            schema_types.extend(t_val if isinstance(t_val, list) else [str(t_val)])
                        if "@graph" in item and isinstance(item["@graph"], list):
                            for node in item["@graph"]:
                                if isinstance(node, dict) and "@type" in node:
                                    nt = node["@type"]
                                    schema_types.extend(nt if isinstance(nt, list) else [str(nt)])
            except Exception:
                schema_types.append("Unparseable JSON-LD block")
        result["schema_types"] = list(dict.fromkeys(schema_types))

        # Check for specific license / CIB mentions on homepage
        cib_matches = re.findall(r"(?:CIB|License|Registration|Lic)\s*#?\s*:?\s*\d{4,10}", full_text, flags=re.IGNORECASE)
        result["license_mentions_on_homepage"] = cib_matches

    except Exception as e:
        result["error"] = str(e)
        return result

    # Check robots.txt
    try:
        parsed_u = urlparse(result["final_url"])
        robots_url = f"{parsed_u.scheme}://{parsed_u.netloc}/robots.txt"
        r_resp = requests.get(robots_url, headers=headers, timeout=10)
        if r_resp.status_code == 200 and "html" not in r_resp.headers.get("Content-Type", "").lower():
            r_text = r_resp.text
            result["robots_status"] = 200
            ai_bots_mentioned = [
                bot for bot in ["GPTBot", "OAI-SearchBot", "Google-Extended", "PerplexityBot", "ClaudeBot"]
                if bot.lower() in r_text.lower()
            ]
            result["ai_bots_in_robots"] = ai_bots_mentioned
            result["robots_excerpt"] = "\n".join(r_text.splitlines()[:15])
        else:
            result["robots_status"] = r_resp.status_code
            result["ai_bots_in_robots"] = []
    except Exception as e:
        result["robots_error"] = str(e)

    return result


def query_gemini_grounded(prompt: str, api_key: str, model: str = "gemini-2.5-flash") -> Dict[str, Any]:
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    payload = {
        "contents": [{"parts": [{"text": prompt}]}],
        "tools": [{"googleSearch": {}}]
    }
    try:
        res = requests.post(url, headers={"x-goog-api-key": api_key}, json=payload, timeout=30)
        if res.status_code == 200:
            data = res.json()
            candidate = data.get("candidates", [{}])[0]
            parts = candidate.get("content", {}).get("parts", [])
            text = "\n".join(p.get("text", "") for p in parts if "text" in p)
            grounding = candidate.get("groundingMetadata", {})
            queries = grounding.get("webSearchQueries", [])
            sources = []
            for chunk in grounding.get("groundingChunks", []):
                web = chunk.get("web", {})
                if web.get("uri") or web.get("title"):
                    sources.append({
                        "title": web.get("title", "Source"),
                        "uri": web.get("uri", "")
                    })
            return {
                "engine": f"Google Search Grounding ({model})",
                "prompt": prompt,
                "text": text,
                "search_queries_run": queries,
                "sources": sources,
                "generation_config_sent": payload.get("generationConfig", {}),
                "raw_api_response": data,
                "status": "success"
            }
        return {"engine": f"Google Search Grounding ({model})", "prompt": prompt, "error": res.text, "status": "error"}
    except Exception as e:
        return {"engine": f"Google Search Grounding ({model})", "prompt": prompt, "error": str(e), "status": "error"}


def extract_bolded_names(text: str) -> List[str]:
    """Extract bolded company/entity names from markdown response."""
    matches = re.findall(r"\*\*([^*]{2,60})\*\*", text)
    cleaned = []
    skip_words = {"note", "key", "important", "summary", "services", "why", "pros", "cons", "location", "phone"}
    for m in matches:
        m_clean = m.strip().rstrip(":")
        if m_clean.lower() not in skip_words and len(m_clean) > 2:
            if m_clean not in cleaned:
                cleaned.append(m_clean)
    return cleaned[:10]


def check_brand_in_text(text: str, brand: str) -> bool:
    lower_t = text.lower()
    lower_b = brand.lower()
    if lower_b in lower_t:
        return True
    # Check distinctive first word if > 4 chars and not generic city/trade
    generic = {"lawton", "yukon", "oklahoma", "roofing", "heating", "cooling", "plumbing", "custom", "complete"}
    first_token = re.sub(r"[^a-z0-9]", "", lower_b.split()[0])
    if len(first_token) >= 5 and first_token not in generic:
        if re.search(rf"\b{re.escape(first_token)}\b", lower_t):
            return True
    return False


def run_inspection_and_benchmark(config: Dict[str, Any]) -> Dict[str, Any]:
    business_name = config["business_name"]
    website_url = config.get("url", "")
    city = config["city"]
    trade = config["trade"]
    competitors = config.get("competitors", [])
    intents = config.get("intents", [])

    print(f"\n[1/2] Inspecting website for {business_name}: {website_url or '(none)'}")
    site_data = inspect_website(website_url)
    if site_data.get("inspected") and "error" not in site_data:
        print(f"      Status {site_data.get('status_code')} in {site_data.get('response_time_ms')}ms | "
              f"Title: {site_data.get('title')} | Internal paths: {len(site_data.get('internal_paths', []))}")
    elif "error" in site_data:
        print(f"      Website inspection error: {site_data['error']}")

    gemini_key = ENV.get("GEMINI_API_KEY", "")
    if not gemini_key:
        print("ERROR: GEMINI_API_KEY not found in environment.")
        sys.exit(1)

    print(f"\n[2/2] Running live search-grounded queries for {business_name} ({city}, OK)...")
    raw_runs: List[Dict[str, Any]] = []
    intent_summaries: List[Dict[str, Any]] = []

    for intent in intents:
        intent_name = intent["name"]
        prompts = intent["prompts"]
        shortlisted_runs = 0
        valid_runs = 0

        for p in prompts:
            formatted_p = p.replace("{{CITY}}", city).replace("{{TRADE}}", trade)
            print(f"   -> Prompt: \"{formatted_p}\"")
            res = query_gemini_grounded(formatted_p, gemini_key)
            if res.get("status") == "success":
                valid_runs += 1
                target_found = check_brand_in_text(res["text"], business_name)
                comp_hits = [c for c in competitors if check_brand_in_text(res["text"], c)]
                surfaced_entities = extract_bolded_names(res["text"])
                if target_found:
                    shortlisted_runs += 1
                res["intent_name"] = intent_name
                res["target_found"] = target_found
                res["competitor_hits"] = comp_hits
                res["surfaced_entities"] = surfaced_entities
                raw_runs.append(res)
                print(f"      Target included: {target_found} | Surfaced: {surfaced_entities[:5]}")
            else:
                print(f"      API Error: {res.get('error')}")
            time.sleep(1)

        slr = (shortlisted_runs / valid_runs) if valid_runs > 0 else 0.0
        intent_summaries.append({
            "intent_name": intent_name,
            "shortlisted_runs": shortlisted_runs,
            "valid_runs": valid_runs,
            "slr_percent": round(slr * 100, 1)
        })

    inslr = (
        round(sum(i["slr_percent"] for i in intent_summaries) / len(intent_summaries), 1)
        if intent_summaries else 0.0
    )

    return {
        "timestamp": datetime.now().isoformat(),
        "business_name": business_name,
        "city": city,
        "trade": trade,
        "website": site_data,
        "intents": intent_summaries,
        "inslr_percent": inslr,
        "total_runs": len(raw_runs),
        "runs": raw_runs
    }


def write_shortlist_check_markdown(data: Dict[str, Any], out_path: str):
    """Write a clean, truthful 1-Page AI Shortlist Check based strictly on recorded observations."""
    bname = data["business_name"]
    city = data["city"]
    trade = data["trade"]
    site = data["website"]
    runs = data["runs"]
    intents = data["intents"]
    inslr = data["inslr_percent"]
    date_str = datetime.now().strftime("%B %d, %Y")

    lines = [
        f"# Local AI Shortlist Check: {bname}",
        f"**Location:** {city}, Oklahoma | **Category:** {trade} | **Date:** {date_str}",
        "**Prepared by:** Jesse Killian, 580 Digital Infrastructure | (580) 919-1294 | jesse@580di.com",
        "",
        "---",
        "",
        "## 1. What We Tested",
        f"We ran {data['total_runs']} unbranded buyer questions through Google's search-grounded AI (`gemini-2.5-flash` with live Google Search retrieval) to see which {city} companies make the shortlist when a customer asks who to hire, what search queries the AI runs behind the scenes, and what websites it pulls from.",
        "",
        f"**Result Summary:** **{bname}** appeared in **{inslr}%** of the tested buyer intents across {data['total_runs']} recorded runs.",
        "",
        "| Buyer Intent Tested | Runs | Times {0} Made the Shortlist | Shortlist Rate |".format(bname),
        "|---|---:|---:|---:|"
    ]

    for item in intents:
        lines.append(
            f"| {item['intent_name']} | {item['valid_runs']} | {item['shortlisted_runs']} of {item['valid_runs']} | **{item['slr_percent']}%** |"
        )

    lines.extend([
        "",
        "---",
        "",
        "## 2. Recorded Search & Answer Log",
        ""
    ])

    for idx, r in enumerate(runs, 1):
        included_str = "YES" if r["target_found"] else "NO"
        queries_run = ", ".join(f"`{q}`" for q in r.get("search_queries_run", [])) or "None recorded"
        surfaced = ", ".join(r.get("surfaced_entities", [])[:6]) or "See excerpt"
        sources = ", ".join(s.get("title", "Source") for s in r.get("sources", [])[:5]) or "None listed"
        excerpt = " ".join(r.get("text", "").split())
        if len(excerpt) > 550:
            excerpt = excerpt[:550] + "..."

        lines.extend([
            f"### Run {idx}: *\"{r['prompt']}\"*",
            f"- **Did {bname} make the answer?** **{included_str}**",
            f"- **Search queries the AI ran behind the scenes:** {queries_run}",
            f"- **Companies surfaced in the answer:** {surfaced}",
            f"- **Sources retrieved by the AI:** {sources}",
            f"- **Answer excerpt:** > {excerpt}",
            ""
        ])

    lines.extend([
        "---",
        "",
        f"## 3. What We Found on {bname}'s Website",
        ""
    ])

    if not site.get("inspected"):
        lines.append(f"- No website URL was inspected ({site.get('reason', '')}).")
    elif "error" in site:
        lines.append(f"- Website check failed with error: `{site['error']}`")
    else:
        schema_str = ", ".join(site.get("schema_types", [])) or "None detected on homepage"
        h1_str = " / ".join(site.get("h1s", [])) or "No H1 heading found"
        h2_str = " | ".join(site.get("h2s", [])[:8]) or "No H2 headings found"
        paths_str = ", ".join(f"`{p}`" for p in site.get("internal_paths", [])[:15]) or "Single-page or no internal links detected"
        lic_str = ", ".join(site.get("license_mentions_on_homepage", [])) or "No explicit CIB/license number pattern detected in homepage text"

        lines.extend([
            f"- **URL Inspected:** {site.get('final_url')} (HTTP {site.get('status_code')}, {site.get('response_time_ms')} ms response)",
            f"- **Page Title:** `{site.get('title') or 'None'}`",
            f"- **Meta Description:** `{site.get('meta_description') or 'None'}`",
            f"- **Homepage H1:** {h1_str}",
            f"- **Homepage H2 Headings:** {h2_str}",
            f"- **Approximate Homepage Word Count:** {site.get('word_count_estimate', 0)} words",
            f"- **Structured Data (JSON-LD) on Homepage:** {schema_str}",
            f"- **License / CIB Mention on Homepage:** {lic_str}",
            f"- **Internal Pages Linked from Homepage:** {paths_str}",
            ""
        ])

    lines.extend([
        "---",
        "",
        "## 4. How 580 Digital Infrastructure Fixes This (Found, Matched, Proven, Shortlisted)",
        "Answer engines do not guess who the best contractor is. They run local searches, pull the pages and profiles that rank, and look for specific facts that answer the buyer's exact question.",
        "",
        "1. **Found (Search & Profile Foundation):** Make sure your core service pages and Google Business Profile can be crawled, indexed, and retrieved for the exact sub-searches the AI runs behind the scenes.",
        "2. **Matched (Specific Service Pages, Not Vague Copy):** Build clear pages for the high-value jobs you want (with exact materials, brands, service areas, and process details) so the AI can match your company to the buyer's problem.",
        "3. **Proven (Verifiable Facts & Reviews):** Put real numbers, licensing, warranties, completed project examples, and specific customer reviews where both buyers and search systems can verify them.",
        "4. **Shortlisted (Ongoing Proof & Measurement):** Add real completed project writeups over time and re-test buyer questions across multiple prompts to track whether your shortlist coverage improves."
    ])

    with open(out_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print(f"\n[Done] Wrote truthful Shortlist Check to: {out_path}")


def main():
    parser = argparse.ArgumentParser(description="580DI Honest AI Shortlist Inspector")
    parser.add_argument("--config", type=str, help="Path to JSON config")
    parser.add_argument("--business", type=str, help="Business name")
    parser.add_argument("--url", type=str, default="", help="Business website URL")
    parser.add_argument("--city", type=str, default="Lawton", help="City")
    parser.add_argument("--trade", type=str, default="Contractor", help="Trade")
    parser.add_argument("--output", type=str, help="Markdown output path")
    args = parser.parse_args()

    if args.config and os.path.exists(args.config):
        with open(args.config, "r", encoding="utf-8") as f:
            config = json.load(f)
    elif args.business:
        config = {
            "business_name": args.business,
            "url": args.url,
            "city": args.city,
            "trade": args.trade,
            "competitors": [],
            "intents": [
                {
                    "name": f"Best {args.trade} in {args.city}",
                    "prompts": [
                        f"Who are the top recommended {args.trade} companies in {args.city} Oklahoma?",
                        f"Who should I hire for {args.trade} in {args.city} OK?"
                    ]
                }
            ]
        }
    else:
        print("Provide --config or --business")
        sys.exit(1)

    slug = re.sub(r"[^a-z0-9]+", "-", config["business_name"].lower()).strip("-")
    out_md = args.output or f"marketing/audits/{slug}-shortlist-check.md"
    out_json = out_md.replace(".md", "-evidence.json")

    data = run_inspection_and_benchmark(config)
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    write_shortlist_check_markdown(data, out_md)


if __name__ == "__main__":
    main()
